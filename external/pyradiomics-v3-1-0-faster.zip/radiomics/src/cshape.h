#include "Vec.h"

#include <numpy/npy_common.h>

#include <algorithm>
#include <limits>
#include <optional>
#include <span>
#include <utility>


namespace radiomics {


struct CoefficientResult3D {
  double SurfaceArea;
  double Volume;
  Vec4<double> Diameters;
};

auto calculate_coefficients(std::span<char> mask,
                            Vec3<npy_intp> const& size,
                            Vec3<npy_intp> const& strides,
                            Vec3<double> const& spacing) noexcept -> std::optional<CoefficientResult3D>;


struct CoefficientResult2D {
  double SurfaceArea;
  double Perimeter;
  double Diameter;
};

auto calculate_coefficients2D(std::span<char> mask,
                              Vec2<npy_intp> const& size,
                              Vec2<npy_intp> const& strides,
                              Vec2<double> const& spacing) -> std::optional<CoefficientResult2D>;





namespace detail {

namespace _3D {

template<typename PointT>
struct Triangle {
  using ValueT = PointT::ValueT;

  PointT A, B, C;
};

// grid vertices define the 8 corners of the marching cube, relative to the origin of the cube
constexpr std::array<Vec3<npy_intp>, 8> grid_vertices { Vec3<npy_intp>
  { 0, 0, 0 }, { 0, 0, 1 }, { 0, 1, 1 }, {0, 1, 0}, { 1, 0, 0 }, {1, 0, 1 }, { 1, 1, 1 }, { 1, 1, 0 }
};

// edgeTable defines which edges contain intersection points, for which the exact intersection point has to be
// interpolated. However, as the intersection point is always 0.5, this can be defined beforehand, and this table is not
// needed
/*static const int edgeTable[128] = {
  0x000, 0x109, 0x203, 0x30a, 0x406, 0x50f, 0x605, 0x70c, 0x80c, 0x905, 0xa0f, 0xb06, 0xc0a, 0xd03, 0xe09, 0xf00,
  0x190, 0x099, 0x393, 0x29a, 0x596, 0x49f, 0x795, 0x69c, 0x99c, 0x895, 0xb9f, 0xa96, 0xd9a, 0xc93, 0xf99, 0xe90,
  0x230, 0x339, 0x033, 0x13a, 0x636, 0x73f, 0x435, 0x53c, 0xa3c, 0xb35, 0x83f, 0x936, 0xe3a, 0xf33, 0xc39, 0xd30,
  0x3a0, 0x2a9, 0x1a3, 0x0aa, 0x7a6, 0x6af, 0x5a5, 0x4ac, 0xbac, 0xaa5, 0x9af, 0x8a6, 0xfaa, 0xea3, 0xda9, 0xca0,
  0x460, 0x569, 0x663, 0x76a, 0x066, 0x16f, 0x265, 0x36c, 0xc6c, 0xd65, 0xe6f, 0xf66, 0x86a, 0x963, 0xa69, 0xb60,
  0x5f0, 0x4f9, 0x7f3, 0x6fa, 0x1f6, 0x0ff, 0x3f5, 0x2fc, 0xdfc, 0xcf5, 0xfff, 0xef6, 0x9fa, 0x8f3, 0xbf9, 0xaf0,
  0x650, 0x759, 0x453, 0x55a, 0x256, 0x35f, 0x055, 0x15c, 0xe5c, 0xf55, 0xc5f, 0xd56, 0xa5a, 0xb53, 0x859, 0x950,
  0x7c0, 0x6c9, 0x5c3, 0x4ca, 0x3c6, 0x2cf, 0x1c5, 0x0cc, 0xfcc, 0xec5, 0xdcf, 0xcc6, 0xbca, 0xac3, 0x9c9, 0x8c0
};*/

// triangulation table defines which triangles (defined by their points as defined in vert_list) are present in the cube.
// The first dimension indicates the specific cube to look up, the second dimension contains sets of 3 points (1 for
// each triangle) (max. no of triangles: 5)
using IdxVec = Vec3<int_fast8_t>;
constexpr std::array<std::array<IdxVec, 6>, 256> tri_table { []() {
  auto const end = IdxVec::sentinel();

  std::array<std::array<IdxVec, 6>, 256> table { std::array<IdxVec, 6>
      { end, end, end, end, end, end },
      { IdxVec { 0, 8, 3 }, end, end, end, end, end },
      { IdxVec { 1, 9, 0 }, end, end, end, end, end },
      { IdxVec { 1, 8, 3 }, { 1, 9, 8 }, end, end, end, end },
      { IdxVec { 1, 2, 10 }, end, end, end, end, end },
      { IdxVec { 0, 8, 3 }, { 1, 2, 10 }, end, end, end, end },
      { IdxVec { 9, 2, 10 }, { 0, 2, 9 }, end, end, end, end },
      { IdxVec { 2, 8, 3 }, { 2, 10, 8 }, { 10, 9, 8 }, end, end, end },
      { IdxVec { 11, 2, 3 }, end, end, end, end, end },
      { IdxVec { 11, 2, 0 }, { 0, 8, 11 }, end, end, end, end },
      { IdxVec { 1, 9, 0 }, { 11, 2, 3 }, end, end, end, end },
      { IdxVec { 11, 2, 1 }, { 1, 9, 11 }, { 9, 8, 11 }, end, end, end },
      { IdxVec { 3, 10, 1 }, { 11, 10, 3 }, end, end, end, end },
      { IdxVec { 10, 1, 0 }, { 0, 8, 10 }, { 8, 11, 10 }, end, end, end },
      { IdxVec { 9, 0, 3 }, { 3, 11, 9 }, { 11, 10, 9 }, end, end, end },
      { IdxVec { 9, 8, 10 }, { 11, 10, 8 }, end, end, end, end },
      { IdxVec { 4, 7, 8 }, end, end, end, end, end },
      { IdxVec { 0, 4, 3 }, { 4, 7, 3 }, end, end, end, end },
      { IdxVec { 1, 9, 0 }, { 4, 7, 8 }, end, end, end, end },
      { IdxVec { 1, 9, 4 }, { 1, 4, 7 }, { 1, 7, 3 }, end, end, end },
      { IdxVec { 1, 2, 10 }, { 4, 7, 8 }, end, end, end, end },
      { IdxVec { 3, 4, 7 }, { 3, 0, 4 }, { 1, 2, 10 }, end, end, end },
      { IdxVec { 9, 2, 10 }, { 9, 0, 2 }, { 4, 7, 8 }, end, end, end },
      { IdxVec { 2, 10, 9 }, { 2, 9, 7 }, { 2, 7, 3 }, { 4, 7, 9 }, end, end },
      { IdxVec { 4, 7, 8 }, { 11, 2, 3 }, end, end, end, end },
      { IdxVec { 11, 4, 7 }, { 11, 2, 4 }, { 2, 0, 4 }, end, end, end },
      { IdxVec { 1, 9, 0 }, { 4, 7, 8 }, { 11, 2, 3 }, end, end, end },
      { IdxVec { 4, 7, 11 }, { 9, 4, 11 }, { 11, 2, 9 }, { 1, 9, 2 }, end, end },
      { IdxVec { 3, 10, 1 }, { 11, 10, 3 }, { 4, 7, 8 }, end, end, end },
      { IdxVec { 11, 10, 1 }, { 1, 4, 11 }, { 1, 0, 4 }, { 4, 7, 11 }, end, end },
      { IdxVec { 4, 7, 8 }, { 9, 0, 3 }, { 3, 11, 9 }, { 11, 10, 9 }, end, end },
      { IdxVec { 4, 7, 11 }, { 4, 11, 9 }, { 9, 11, 10 }, end, end, end },
      { IdxVec { 9, 5, 4 }, end, end, end, end, end },
      { IdxVec { 9, 5, 4 }, { 0, 8, 3 }, end, end, end, end },
      { IdxVec { 0, 5, 4 }, { 0, 1, 5 }, end, end, end, end },
      { IdxVec { 8, 5, 4 }, { 8, 3, 5 }, { 3, 1, 5 }, end, end, end },
      { IdxVec { 1, 2, 10 }, { 9, 5, 4 }, end, end, end, end },
      { IdxVec { 0, 8, 3 }, { 1, 2, 10 }, { 9, 5, 4 }, end, end, end },
      { IdxVec { 2, 10, 5 }, { 5, 4, 2 }, { 2, 4, 0 }, end, end, end },
      { IdxVec { 2, 10, 5 }, { 3, 2, 5 }, { 3, 5, 4 }, { 8, 3, 4 }, end, end },
      { IdxVec { 9, 5, 4 }, { 11, 2, 3 }, end, end, end, end },
      { IdxVec { 11, 2, 0 }, { 0, 8, 11 }, { 9, 5, 4 }, end, end, end },
      { IdxVec { 0, 5, 4 }, { 0, 1, 5 }, { 11, 2, 3 }, end, end, end },
      { IdxVec { 2, 1, 5 }, { 2, 5, 8 }, { 11, 2, 8 }, { 5, 4, 8 }, end, end },
      { IdxVec { 3, 10, 1 }, { 11, 10, 3 }, { 9, 5, 4 }, end, end, end },
      { IdxVec { 5, 4, 9 }, { 10, 1, 0 }, { 0, 8, 10 }, { 8, 11, 10 }, end, end },
      { IdxVec { 5, 4, 0 }, { 5, 0, 11 }, { 10, 5, 11 }, { 11, 0, 3 }, end, end },
      { IdxVec { 5, 4, 8 }, { 10, 5, 8 }, { 11, 10, 8 }, end, end, end },
      { IdxVec { 7, 8, 9 }, { 5, 7, 9 }, end, end, end, end },
      { IdxVec { 3, 0, 9 }, { 5, 3, 9 }, { 3, 5, 7 }, end, end, end },
      { IdxVec { 7, 8, 0 }, { 0, 1, 7 }, { 7, 1, 5 }, end, end, end },
      { IdxVec { 1, 5, 7 }, { 1, 7, 3 }, end, end, end, end },
      { IdxVec { 7, 8, 9 }, { 5, 7, 9 }, { 1, 2, 10 }, end, end, end },
      { IdxVec { 1, 2, 10 }, { 3, 0, 9 }, { 3, 9, 5 }, { 3, 5, 7 }, end, end },
      { IdxVec { 0, 2, 8 }, { 8, 2, 5 }, { 8, 5, 7 }, { 2, 10, 5 }, end, end },
      { IdxVec { 2, 10, 5 }, { 2, 5, 3 }, { 3, 5, 7 }, end, end, end },
      { IdxVec { 5, 7, 9 }, { 7, 8, 9 }, { 11, 2, 3 }, end, end, end },
      { IdxVec { 5, 7, 9 }, { 9, 7, 2 }, { 2, 0, 9 }, { 11, 2, 7 }, end, end },
      { IdxVec { 11, 2, 3 }, { 0, 1, 8 }, { 1, 7, 8 }, { 1, 5, 7 }, end, end },
      { IdxVec { 2, 1, 11 }, { 1, 7, 11 }, { 1, 5, 7 }, end, end, end },
      { IdxVec { 7, 8, 9 }, { 5, 7, 9 }, { 3, 10, 1 }, { 11, 10, 3 }, end, end },
      { IdxVec { 5, 7, 0 }, { 5, 0, 9 }, { 7, 11, 0 }, { 10, 1, 0 }, { 11, 10, 0 }, end },
      { IdxVec { 11, 10, 0 }, { 0, 3, 11 }, { 10, 5, 0 }, { 0, 7, 8 }, { 5, 7, 0 }, end },
      { IdxVec { 11, 10, 5 }, { 5, 7, 11 }, end, end, end, end },
      { IdxVec { 6, 5, 10 }, end, end, end, end, end },
      { IdxVec { 0, 8, 3 }, { 6, 5, 10 }, end, end, end, end },
      { IdxVec { 1, 9, 0 }, { 6, 5, 10 }, end, end, end, end },
      { IdxVec { 1, 8, 3 }, { 1, 9, 8 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 1, 6, 5 }, { 1, 2, 6 }, end, end, end, end },
      { IdxVec { 1, 6, 5 }, { 1, 2, 6 }, { 0, 8, 3 }, end, end, end },
      { IdxVec { 9, 6, 5 }, { 9, 0, 6 }, { 0, 2, 6 }, end, end, end },
      { IdxVec { 5, 9, 8 }, { 5, 8, 2 }, { 5, 2, 6 }, { 8, 3, 2 }, end, end },
      { IdxVec { 11, 2, 3 }, { 6, 5, 10 }, end, end, end, end },
      { IdxVec { 11, 2, 0 }, { 0, 8, 11 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 1, 9, 0 }, { 11, 2, 3 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 11, 2, 1 }, { 1, 9, 11 }, { 9, 8, 11 }, { 6, 5, 10 }, end, end },
      { IdxVec { 6, 3, 11 }, { 6, 5, 3 }, { 5, 1, 3 }, end, end, end },
      { IdxVec { 0, 8, 11 }, { 0, 11, 5 }, { 0, 5, 1 }, { 5, 11, 6 }, end, end },
      { IdxVec { 6, 3, 11 }, { 0, 3, 6 }, { 0, 6, 5 }, { 0, 5, 9 }, end, end },
      { IdxVec { 6, 5, 9 }, { 6, 9, 11 }, { 11, 9, 8 }, end, end, end },
      { IdxVec { 4, 7, 8 }, { 6, 5, 10 }, end, end, end, end },
      { IdxVec { 0, 4, 3 }, { 4, 7, 3 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 1, 9, 0 }, { 4, 7, 8 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 1, 9, 4 }, { 1, 4, 7 }, { 1, 7, 3 }, { 6, 5, 10 }, end, end },
      { IdxVec { 4, 7, 8 }, { 1, 6, 5 }, { 1, 2, 6 }, end, end, end },
      { IdxVec { 0, 4, 3 }, { 4, 7, 3 }, { 1, 6, 5 }, { 1, 2, 6 }, end, end },
      { IdxVec { 4, 7, 8 }, { 9, 6, 5 }, { 9, 0, 6 }, { 0, 2, 6 }, end, end },
      { IdxVec { 7, 3, 9 }, { 4, 7, 9 }, { 3, 2, 9 }, { 5, 9, 6 }, { 2, 6, 9 }, end },
      { IdxVec { 11, 2, 3 }, { 4, 7, 8 }, { 6, 5, 10 }, end, end, end },
      { IdxVec { 11, 4, 7 }, { 11, 2, 4 }, { 2, 0, 4 }, { 6, 5, 10 }, end, end },
      { IdxVec { 1, 9, 0 }, { 11, 2, 3 }, { 4, 7, 8 }, { 6, 5, 10 }, end, end },
      { IdxVec { 4, 7, 11 }, { 9, 4, 11 }, { 11, 2, 9 }, { 1, 9, 2 }, { 6, 5, 10 }, end },
      { IdxVec { 4, 7, 8 }, { 6, 3, 11 }, { 6, 5, 3 }, { 5, 1, 3 }, end, end },
      { IdxVec { 5, 1, 11 }, { 5, 11, 6 }, { 1, 0, 11 }, { 4, 7, 11 }, { 0, 4, 11 }, end },
      { IdxVec { 4, 7, 8 }, { 6, 3, 11 }, { 0, 3, 6 }, { 0, 6, 5 }, { 0, 5, 9 }, end },
      { IdxVec { 6, 5, 9 }, { 6, 9, 11 }, { 4, 7, 9 }, { 7, 11, 9 }, end, end },
      { IdxVec { 10, 4, 9 }, { 6, 4, 10 }, end, end, end, end },
      { IdxVec { 10, 4, 9 }, { 6, 4, 10 }, { 0, 8, 3 }, end, end, end },
      { IdxVec { 0, 1, 10 }, { 10, 6, 0 }, { 6, 4, 0 }, end, end, end },
      { IdxVec { 1, 8, 3 }, { 1, 6, 8 }, { 8, 6, 4 }, { 6, 1, 10 }, end, end },
      { IdxVec { 1, 4, 9 }, { 1, 2, 4 }, { 2, 6, 4 }, end, end, end },
      { IdxVec { 1, 4, 9 }, { 1, 2, 4 }, { 2, 6, 4 }, { 0, 8, 3 }, end, end },
      { IdxVec { 0, 2, 4 }, { 4, 2, 6 }, end, end, end, end },
      { IdxVec { 8, 3, 2 }, { 8, 2, 4 }, { 4, 2, 6 }, end, end, end },
      { IdxVec { 11, 2, 3 }, { 10, 4, 9 }, { 6, 4, 10 }, end, end, end },
      { IdxVec { 11, 2, 0 }, { 0, 8, 11 }, { 10, 4, 9 }, { 6, 4, 10 }, end, end },
      { IdxVec { 11, 2, 3 }, { 0, 1, 10 }, { 10, 6, 0 }, { 6, 4, 0 }, end, end },
      { IdxVec { 6, 4, 1 }, { 6, 1, 10 }, { 1, 4, 8 }, { 11, 2, 1 }, { 1, 8, 11 }, end },
      { IdxVec { 9, 6, 4 }, { 3, 6, 9 }, { 1, 3, 9 }, { 11, 6, 3 }, end, end },
      { IdxVec { 1, 8, 11 }, { 0, 8, 1 }, { 11, 6, 1 }, { 1, 4, 9 }, { 6, 4, 1 }, end },
      { IdxVec { 6, 3, 11 }, { 0, 3, 6 }, { 6, 4, 0 }, end, end, end },
      { IdxVec { 8, 6, 4 }, { 6, 8, 11 }, end, end, end, end },
      { IdxVec { 6, 7, 10 }, { 7, 8, 10 }, { 8, 9, 10 }, end, end, end },
      { IdxVec { 6, 7, 10 }, { 0, 10, 7 }, { 0, 9, 10 }, { 0, 7, 3 }, end, end },
      { IdxVec { 6, 7, 10 }, { 1, 10, 7 }, { 1, 7, 8 }, { 0, 1, 8 }, end, end },
      { IdxVec { 6, 7, 10 }, { 1, 10, 7 }, { 1, 7, 3 }, end, end, end },
      { IdxVec { 1, 2, 6 }, { 1, 6, 8 }, { 1, 8, 9 }, { 6, 7, 8 }, end, end },
      { IdxVec { 2, 6, 9 }, { 1, 2, 9 }, { 6, 7, 9 }, { 3, 0, 9 }, { 7, 3, 9 }, end },
      { IdxVec { 0, 7, 8 }, { 7, 0, 6 }, { 6, 0, 2 }, end, end, end },
      { IdxVec { 2, 7, 3 }, { 2, 6, 7 }, end, end, end, end },
      { IdxVec { 11, 2, 3 }, { 6, 7, 10 }, { 7, 8, 10 }, { 8, 9, 10 }, end, end },
      { IdxVec { 2, 0, 7 }, { 11, 2, 7 }, { 0, 9, 7 }, { 6, 7, 10 }, { 9, 10, 7 }, end },
      { IdxVec { 6, 7, 10 }, { 1, 10, 7 }, { 1, 7, 8 }, { 0, 1, 8 }, { 11, 2, 3 }, end },
      { IdxVec { 11, 2, 1 }, { 1, 7, 11 }, { 10, 6, 1 }, { 1, 6, 7 }, end, end },
      { IdxVec { 8, 9, 6 }, { 6, 7, 8 }, { 1, 6, 9 }, { 11, 6, 3 }, { 1, 3, 6 }, end },
      { IdxVec { 0, 9, 1 }, { 6, 7, 11 }, end, end, end, end },
      { IdxVec { 0, 7, 8 }, { 7, 0, 6 }, { 0, 3, 11 }, { 11, 6, 0 }, end, end },
      { IdxVec { 6, 7, 11 }, end, end, end, end, end }
  };

  std::span<std::array<IdxVec, 6>, 128> const firstHalf { table.begin(), 128 };
  std::span<std::array<IdxVec, 6>, 128> secondHalf { std::next(table.begin(), 128), 128 };

  // Isosurface is symmetrical around the midpoint
  // Flip entries with i > 127 to ensure correct volume sign
  std::transform(firstHalf.rbegin(), firstHalf.rend(),
                 secondHalf.begin(),
                 [](std::array<IdxVec, 6> const& idxVecs) {
    std::array<IdxVec, 6> invertedIdxVecs {};
    std::transform(idxVecs.cbegin(), idxVecs.cend(),
                   invertedIdxVecs.begin(),
                   [](IdxVec const& idxVec) { return IdxVec { idxVec[2], idxVec[0], idxVec[1] }; });
    return invertedIdxVecs;
  });

  return table;
}() };

// Vertlist represents the location of some point somewhere on an edge of the cube, relative to the origin (0, 0, 0).
// As the points on the cube are always either 0 or 1 (masked/not-masked) that other point is always halfway.
// Therefore, vertlist is constant and can be defined static (only works when the intersection point is constant,
// in this case the intersection point is always 0.5). The edge represented is defined by the gridAngle points as follows:
// { { 1, 0 }, { 2, 1 }, { 3, 2 }, { 3, 0 }, { 5, 4 }, { 6, 5 },
//   { 7, 6 }, { 7, 4 }, { 4, 0 }, { 5, 1 }, { 6, 2 }, { 7, 0 } }
constexpr std::array<Point3<double>, 12> vert_list { Point3<double>
  { 0, 0, 0.5 }, { 0, 0.5, 1 }, { 0, 1, 0.5 }, { 0, 0.5, 0 }, { 1, 0, 0.5 }, { 1, 0.5, 1 },
  { 1, 1, 0.5 }, { 1, 0.5, 0 }, { 0.5, 0, 0 }, { 0.5, 0, 1 }, { 0.5, 1, 1 }, { 0.5, 1, 0 }
};

}

namespace _2D {

template<typename PointT>
struct Line {
  using ValueT = PointT::ValueT;

  PointT A, B;
};

constexpr std::array<Point2<npy_intp>, 4> grid_vertices { Point2<npy_intp> { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 } };

constexpr std::array<std::array<Vec2<int_fast8_t>, 3>, 16> line_table { std::array<Vec2<int_fast8_t>, 3>
    { Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 3,  0 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 0,  1 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 3,  1 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 1,  2 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 1,  2 }, { 3,  0 }, Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 0,  2 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 3,  2 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 2,  3 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 2,  0 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 0,  1 }, { 2,  3 }, Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 2,  1 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 1,  3 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 1,  0 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t> { 0,  3 }, Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
    { Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel(), Vec2<int_fast8_t>::sentinel() },
};

static constexpr std::array<Vec2<double>, 4> vert_list { Vec2<double> { 0, 0.5 }, { 0.5, 1 }, { 1, 0.5 }, { 0.5, 0 } };

}
}
}