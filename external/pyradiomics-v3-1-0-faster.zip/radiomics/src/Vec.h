#pragma once

#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <iterator>
#include <limits>
#include <sstream>
#include <type_traits>


namespace radiomics {

template<typename T>
concept ArithmeticT = std::is_arithmetic_v<T>;

using dims_t = uint_fast8_t;

template<ArithmeticT T, uint_fast8_t n_dims>
struct Vec : public std::array<T, n_dims> {
  using ValueT = T;

  [[nodiscard]] static consteval auto
  sentinel() noexcept -> Vec {
    Vec v {};
    v[0] = std::numeric_limits<ValueT>::max();
    return v;
  }

  [[nodiscard]] auto
  is_sentinel() const noexcept -> bool {
    return (*this)[0] == std::numeric_limits<ValueT>::max();
  }

  [[nodiscard]] auto
  to_string() const noexcept -> std::string {
    std::stringstream ss;
    ss << "(";
    std::copy(this->cbegin(), this->cend(), std::ostream_iterator<ValueT>(ss, ", "));
    ss << ")";
    return ss.str();
  }

  auto
  print() const noexcept -> void {
    std::cout << to_string() << std::endl;
  }

  [[nodiscard]] static constexpr auto
  max() noexcept -> Vec {
    Vec v {};
    for (uint_fast8_t i = 0; i < n_dims; ++i)
      v[i] = std::numeric_limits<ValueT>::max();
    return v;
  }

  [[nodiscard]] static constexpr auto
  max() noexcept -> Vec
  requires (n_dims == 3) {
    return { std::numeric_limits<ValueT>::max(),
             std::numeric_limits<ValueT>::max(),
             std::numeric_limits<ValueT>::max() };
  }

  [[nodiscard]] static constexpr auto
  max() noexcept -> Vec
  requires (n_dims == 2) {
    return { std::numeric_limits<ValueT>::max(), std::numeric_limits<ValueT>::max() };
  }

  [[nodiscard]] static constexpr auto
  min() noexcept -> Vec {
    Vec v {};
    for (uint_fast8_t i = 0; i < n_dims; ++i)
      v[i] = std::numeric_limits<ValueT>::min();
    return v;
  }

  [[nodiscard]] static constexpr auto
  min() noexcept -> Vec
  requires (n_dims == 3) {
    return { std::numeric_limits<ValueT>::min(),
             std::numeric_limits<ValueT>::min(),
             std::numeric_limits<ValueT>::min() };
  }

  [[nodiscard]] static constexpr auto
  min() noexcept -> Vec
  requires (n_dims == 2) {
    return { std::numeric_limits<ValueT>::min(), std::numeric_limits<ValueT>::min() };
  }

  [[nodiscard]] auto
  operator+ (Vec const& other) const noexcept -> Vec {
    Vec point {*this };
    point += other;
    return point;
  }

  [[nodiscard]] auto
  operator+ (Vec const& other) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] + other[0],
             (*this)[1] + other[1],
             (*this)[2] + other[2] };
  }

  [[nodiscard]] auto
  operator+ (Vec const& other) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] + other[0], (*this)[1] + other[1] };
  }

  [[nodiscard]] auto
  operator- (Vec const& other) const noexcept -> Vec {
    Vec point {*this };
    point -= other;
    return point;
  }

  [[nodiscard]] auto
  operator- (Vec const& other) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] - other[0],
             (*this)[1] - other[1],
             (*this)[2] - other[2] };
  }

  [[nodiscard]] auto
  operator- (Vec const& other) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] - other[0], (*this)[1] - other[1] };
  }


  [[nodiscard]] auto
  operator* (Vec const& other) const noexcept -> Vec {
    Vec point {*this };
    point *= other;
    return point;
  }

  [[nodiscard]] auto
  operator* (Vec const& other) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] * other[0],
             (*this)[1] * other[1],
             (*this)[2] * other[2] };
  }

  [[nodiscard]] auto
  operator* (T factor) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] * factor, (*this)[1] * factor };
  }

  [[nodiscard]] auto
  operator* (T factor) const noexcept -> Vec {
    Vec point {*this };
    point *= factor;
    return point;
  }

  [[nodiscard]] auto
  operator* (T factor) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] * factor,
             (*this)[1] * factor,
             (*this)[2] * factor };
  }

  [[nodiscard]] auto
  operator* (Vec const& other) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] * other[0], (*this)[1] * other[1] };
  }

  [[nodiscard]] auto
  operator/ (Vec const& other) const noexcept -> Vec {
    Vec point {*this };
    point /= other;
    return point;
  }

  [[nodiscard]] auto
  operator/ (Vec const& other) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] / other[0],
             (*this)[1] / other[1],
             (*this)[2] / other[2] };
  }

  [[nodiscard]] auto
  operator/ (Vec const& other) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] / other[0],
             (*this)[1] / other[1] };
  }

  [[nodiscard]] auto
  operator/ (T factor) const noexcept -> Vec {
    Vec point {*this };
    point /= factor;
    return point;
  }

  [[nodiscard]] auto
  operator/ (T factor) const noexcept -> Vec
  requires (n_dims == 3) {
    return { (*this)[0] / factor,
             (*this)[1] / factor,
             (*this)[2] / factor };
  }

  [[nodiscard]] auto
  operator/ (T factor) const noexcept -> Vec
  requires (n_dims == 2) {
    return { (*this)[0] / factor,
             (*this)[1] / factor };
  }

  auto
  operator+= (Vec const& other) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] += other[i];
  }

  auto
  operator+= (Vec const& other) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] += other[0];
    (*this)[1] += other[1];
    (*this)[2] += other[2];
  }

  auto
  operator+= (Vec const& other) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] += other[0];
    (*this)[1] += other[1];
  }

  auto
  operator-= (Vec const& other) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] -= other[i];
  }

  auto
  operator-= (Vec const& other) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] -= other[0];
    (*this)[1] -= other[1];
    (*this)[2] -= other[2];
  }

  auto
  operator-= (Vec const& other) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] -= other[0];
    (*this)[1] -= other[1];
  }

  auto
  operator*= (Vec const& other) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] *= other[i];
  }

  auto
  operator*= (Vec const& other) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] *= other[0];
    (*this)[1] *= other[1];
    (*this)[2] *= other[2];
  }

  auto
  operator*= (Vec const& other) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] *= other[0];
    (*this)[1] *= other[1];
  }

  auto
  operator*= (T factor) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] *= factor;
  }

  auto
  operator*= (T factor) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] *= factor;
    (*this)[1] *= factor;
    (*this)[2] *= factor;
  }

  auto
  operator*= (T factor) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] *= factor;
    (*this)[1] *= factor;
  }

  auto
  operator/= (Vec const& other) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] /= other[i];
  }

  auto
  operator/= (Vec const& other) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] /= other[0];
    (*this)[1] /= other[1];
    (*this)[2] /= other[2];
  }

  auto
  operator/= (Vec const& other) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] /= other[0];
    (*this)[1] /= other[1];
  }

  auto
  operator/= (T factor) noexcept -> void {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] /= factor;
  }

  auto
  operator/= (T factor) noexcept -> void
  requires (n_dims == 3) {
    (*this)[0] /= factor;
    (*this)[1] /= factor;
    (*this)[2] /= factor;
  }

  auto
  operator/= (T factor) noexcept -> void
  requires (n_dims == 2) {
    (*this)[0] /= factor;
    (*this)[1] /= factor;
  }

  [[nodiscard]] auto
  dot(Vec const& other) const noexcept -> T {
    T sum = 0;
    for (dims_t i = 0; i < n_dims; i++)
      sum += (*this)[i] * other[i];

    return sum;
  }

  [[nodiscard]] auto
  dot(Vec const& other) const noexcept -> T
  requires (n_dims == 3) {
    return (*this)[0] * other[0] + (*this)[1] * other[1] + (*this)[2] * other[2];
  }

  [[nodiscard]] auto
  dot(Vec const& other) const noexcept -> T
  requires (n_dims == 2) {
    return (*this)[0] * other[0] + (*this)[1] * other[1];
  }

  [[nodiscard]] auto
  cross(Vec const& other) const noexcept -> Vec
  requires (n_dims == 3) {
    return { ((*this)[1] * other[2]) - (other[1] * (*this)[2]),
             ((*this)[2] * other[0]) - (other[2] * (*this)[0]),
             ((*this)[0] * other[1]) - (other[0] * (*this)[1]) };
  }

  [[nodiscard]] auto
  length() const noexcept -> T {
    return sqrt(dot(*this));
  }

  auto
  normalize() noexcept -> void {
    (*this) / length();
  }

  [[nodiscard]] auto
  distance(Vec const& other) const noexcept -> T {
    return sqrt(((*this) - other).sum_of_squares());
  }

  [[nodiscard]] auto
  distance(Vec const& other, Vec const& direction) const noexcept -> T {
    Vec const& difference = (*this) - other;

    T const& len = difference.length();
    T const& projection_len = direction.dot(difference);

    return sqrt(len * len - projection_len * projection_len);
  }

  [[nodiscard]] auto
  sum_of_squares() const noexcept -> T {
    Vec const& squared {dot(*this) };

    T sum = 0;
    for (dims_t i = 0; i < n_dims; i++)
      sum += squared[i];

    return sum;
  }

  [[nodiscard]] auto
  sum_of_squares() const noexcept -> T
  requires (n_dims == 3) {
    Vec const& squared {dot(*this) };
    return squared[0] + squared[1] + squared[2];
  }

  [[nodiscard]] auto
  sum_of_squares() const noexcept -> T
  requires (n_dims == 2) {
    Vec const& squared {dot(*this) };
    return squared[0] + squared[1];
  }

  auto
  to_square_root() noexcept -> Vec& {
    for (dims_t i = 0; i < n_dims; i++)
      (*this)[i] = sqrt((*this)[i]);

    return *this;
  }

  auto
  to_square_root() noexcept -> Vec&
  requires (n_dims == 4) {
    (*this)[0] = sqrt((*this)[0]);
    (*this)[1] = sqrt((*this)[1]);
    (*this)[2] = sqrt((*this)[2]);
    (*this)[3] = sqrt((*this)[3]);
    return *this;
  }

  auto
  to_square_root() noexcept -> Vec&
  requires (n_dims == 3) {
    (*this)[0] = sqrt((*this)[0]);
    (*this)[1] = sqrt((*this)[1]);
    (*this)[2] = sqrt((*this)[2]);
  }

  auto
  to_square_root() noexcept -> Vec&
  requires (n_dims == 2) {
    (*this)[0] = sqrt((*this)[0]);
    (*this)[1] = sqrt((*this)[1]);
  }

  auto
  scale_and_translate(T factor, Vec const& translation) noexcept -> void {
    (*this) += translation * factor;
  }

};

template<ArithmeticT T> using Vec2 = Vec<T, 2>;
template<ArithmeticT T> using Point2 = Vec2<T>;

template<ArithmeticT T> using Vec3 = Vec<T, 3>;
template<ArithmeticT T> using Point3 = Vec3<T>;

template<ArithmeticT T> using Vec4 = Vec<T, 4>;
template<ArithmeticT T> using Point4 = Vec4<T>;

}

