#pragma once

#include "../Vec.h"

#include <algorithm>
#include <bit>
#include <cassert>
#include <optional>
#include <random>
#include <span>
#include <vector>


namespace radiomics::fstdiameter::impl {

constexpr size_t brute_force_size_threshold = 256;

template<ArithmeticT T, uint_fast8_t n_dims>
struct BoundingBox {
  using PointT = Vec<T, n_dims>;
  using PointRefT = std::reference_wrapper<PointT const>;

  PointT min_point;
  PointT max_point;
  T diameter;

  BoundingBox(BoundingBox const& bbox_left, BoundingBox const& bbox_right) :
      min_point { [&]() {
        PointT min;
        for (int i = 0; i < n_dims; ++i)
          min[i] = std::min(bbox_left.min_point[i], bbox_right.min_point[i]);
        return min;
      }() },
      max_point { [&]() {
        PointT max;
        for (int i = 0; i < n_dims; ++i)
          max[i] = std::max(bbox_left.max_point[i], bbox_right.max_point[i]);
        return max;
      }() },
      diameter { min_point.distance(max_point) } {}

  explicit BoundingBox(std::span<PointRefT> _node_points) :
      min_point { PointT::max() },
      max_point { PointT::min() },
      diameter {} {

    for (auto it = _node_points.begin(); it != _node_points.end(); ++it) {
      for (uint_fast8_t i = 0; i < n_dims; ++i) {
        min_point[i] = std::min(min_point[i], it->get()[i]);
        max_point[i] = std::max(max_point[i], it->get()[i]);
      }
    }

    diameter = min_point.distance(max_point);
  }

  [[nodiscard]] auto
  longest_dimension() const -> uint_fast8_t {
    Vec<T, n_dims> const difference = max_point - min_point;

    auto const maxIt = std::max_element(difference.begin(), difference.end());

    return std::distance(difference.begin(), maxIt);
  }
};

template<ArithmeticT T, uint_fast8_t n_dims>
struct TreeNode {
  using PointT = Vec<T, n_dims>;
  using PointRefT = std::reference_wrapper<PointT const>;
  using BoundingBoxT = BoundingBox<T, n_dims>;

  size_t idx;
  std::span<PointRefT> points;
  BoundingBoxT bounding_box;

  explicit TreeNode(size_t _idx, std::span<PointRefT> _node_points) :
      idx { _idx },
      points { _node_points },
      bounding_box { points } {}
};

template<ArithmeticT T, uint_fast8_t n_dims>
struct NodePair {
  using TreeNodeT = TreeNode<T, n_dims>;

  size_t left_idx;
  size_t right_idx;
  T max_diameter;

  NodePair(TreeNodeT const& left_node, TreeNodeT const& right_node) :
      left_idx { left_node.idx },
      right_idx { right_node.idx },
      max_diameter { (BoundingBox<T, n_dims> { left_node.bounding_box, right_node.bounding_box }).diameter } {}
};

template<ArithmeticT T, uint_fast8_t n_dims>
class Tree {
  using PointT = Vec<T, n_dims>;
  using PointRefT = std::reference_wrapper<PointT const>;
  using TreeNodeT = TreeNode<T, n_dims>;
  using NodePairT = NodePair<T, n_dims>;

  std::vector<PointRefT> points;
  std::vector<std::optional<TreeNodeT>> nodes {};

public:
  explicit Tree(std::span<PointT const> _points) :
      points { [_points]() {
        std::vector<PointRefT> vec {};
        vec.reserve(_points.size());
        for (PointT const& point : _points)
          vec.emplace_back(std::cref(point));
        return vec;
      }() } {
    nodes.emplace_back(TreeNodeT { 0, std::span<PointRefT> { points.begin(), points.end() } });
  }

  explicit Tree(std::span<PointRefT> _points) :
      points { _points.begin(), _points.end() } {
    nodes.emplace_back(TreeNodeT { 0, std::span<PointRefT> { points.begin(), points.end() } });
  }

  [[nodiscard]] auto
  tree_height() const noexcept -> size_t { return std::countr_zero(std::bit_ceil(nodes.size() + 1)) - 1; }

  [[nodiscard]] auto
  node_height(TreeNodeT const& node) const noexcept -> size_t {
    return std::countr_zero(std::bit_ceil(node.idx + 2)) - 1;
  }

  auto
  insert_children(size_t parent_node_idx,
                  std::span<PointRefT> left_span_points,
                  std::span<PointRefT> right_span_points) noexcept -> void {
    if (node_height(*nodes[parent_node_idx]) == tree_height())
      nodes.resize((1 << (tree_height() + 2)) - 1);

    size_t const left_child_idx = 2 * parent_node_idx + 1;
    size_t const right_child_idx = left_child_idx + 1;

    nodes[left_child_idx ].emplace(TreeNodeT { left_child_idx, std::move(left_span_points) });
    nodes[right_child_idx].emplace(TreeNodeT { right_child_idx, std::move(right_span_points) });
  };

  [[nodiscard]] auto
  root_node() const noexcept -> TreeNodeT const& { return *nodes[0]; }

  [[nodiscard]] auto
  node(size_t node_idx) const noexcept -> TreeNodeT const& { return *nodes[node_idx]; }

  [[nodiscard]] auto
  has_left_child(TreeNodeT const& parent_node) const noexcept -> bool {
    size_t const left_child_idx = 2 * parent_node.idx + 1;
    return left_child_idx < nodes.size() && nodes[left_child_idx];
  }

  [[nodiscard]] auto
  left_child(TreeNodeT const& parent_node) noexcept -> TreeNodeT& { return *nodes[2 * parent_node.idx + 1]; }

  [[nodiscard]] auto
  right_child(TreeNodeT const& parent_node) noexcept -> TreeNodeT& { return *nodes[2 * parent_node.idx + 2]; }

  [[nodiscard]] auto
  get_points() const noexcept -> std::vector<PointRefT> const& { return points; }

  [[nodiscard]] auto
  bruteforce_max_diameter(NodePairT node_pair) const noexcept -> T {
    TreeNodeT const& left_node  = *nodes[node_pair.left_idx];
    TreeNodeT const& right_node = *nodes[node_pair.right_idx];

    T max_distance = 0.0;
    for (auto a_it = left_node.points.begin(); a_it != left_node.points.end(); ++a_it)
      for (auto b_it = right_node.points.begin(); b_it != right_node.points.end(); ++b_it)
        max_distance = std::max(max_distance, a_it->get().distance(b_it->get()));

    return max_distance;
  }

  auto
  split_node(size_t node_idx) -> void {
    TreeNodeT& node = *nodes[node_idx];
    if (has_left_child(node))
      return;

    auto const& bbox = node.bounding_box;
    uint_fast8_t const dim = bbox.longest_dimension();
    T const split_value = (bbox.min_point[dim] + bbox.max_point[dim]) / 2.0;

    auto const right_begin_it = std::partition(node.points.begin(), node.points.end(),
                                               [&](PointT const& point) { return point[dim] < split_value; });

    insert_children(node.idx,
                    std::span<PointRefT> { node.points.begin(), right_begin_it },
                    std::span<PointRefT> { right_begin_it, node.points.end() });
  };

  [[nodiscard]] auto
  should_bruteforce(NodePairT const& node_pair) const noexcept -> bool {
    return nodes[node_pair.left_idx ]->points.size() < brute_force_size_threshold
        && nodes[node_pair.right_idx]->points.size() < brute_force_size_threshold;
  }
};

template<ArithmeticT T, uint_fast8_t n_dims>
class NodePairHeap {
  using NodePairT = NodePair<T, n_dims>;

  std::vector<NodePairT> vector {};
  size_t heap_size = 0;

public:
  explicit NodePairHeap(size_t initial_size) { vector.reserve(initial_size); }

  auto
  push(NodePairT&& node_pair) noexcept -> void {
    vector.emplace(heap_end(), std::move(node_pair));
    ++heap_size;
    std::push_heap(vector.begin(), heap_end(),
                   [](auto const& a, auto const& b) { return a.max_diameter < b.max_diameter; });
  }

  [[nodiscard]] auto
  pop() noexcept -> NodePairT const& {
    assert(heap_size > 0);

    std::pop_heap(vector.begin(), heap_end(),
                  [](auto const& a, auto const& b) { return a.max_diameter < b.max_diameter; });
    --heap_size;
    return *heap_end();
  }

  [[nodiscard]] auto
  empty() const noexcept -> bool { return heap_size == 0; }

private:
  [[nodiscard]] auto
  heap_end() noexcept -> std::vector<NodePairT>::iterator { return std::next(vector.begin(), heap_size); }
};

template<ArithmeticT T, uint_fast8_t n_dims>
class Algorithm {
  using PointT = Vec<T, n_dims>;
  using PointRefT = std::reference_wrapper<PointT const>;
  using NodePairT = NodePair<T, n_dims>;
  using TreeNodeT = TreeNode<T, n_dims>;
  using TreeT = Tree<T, n_dims>;
  using NodePairHeapT = NodePairHeap<T, n_dims>;

  static constexpr T epsilon = 0.0;

  TreeT tree;
  NodePairHeapT heap {};
  T max_diameter = 0.0;

public:
  explicit Algorithm(std::span<PointT const> points) :
      tree { points },
      heap { points.size() / 4 } {}

  explicit Algorithm(std::span<PointRefT> points) :
      tree { points },
      heap { points.size() / 4 } {}

  [[nodiscard]] auto
  operator()() -> T {
    max_diameter = initial_max_diameter_point_pair_approximation();

    TreeNodeT const& root_node = tree.root_node();
    NodePairT&& root_node_pair { root_node, root_node };
    heap.push(std::move(root_node_pair));

    while (!heap.empty()) {
      NodePairT const& max_diameter_node_pair = heap.pop();

      if (max_diameter_node_pair.max_diameter <= ((1.0 + epsilon) * max_diameter))
        continue;

      if (tree.should_bruteforce(max_diameter_node_pair))
        max_diameter = std::max(max_diameter, tree.bruteforce_max_diameter(max_diameter_node_pair));
      else
        split_node_pair(max_diameter_node_pair);
    }

    return max_diameter;
  };

private:
  [[nodiscard]] auto
  initial_max_diameter_point_pair_approximation() const noexcept -> T {
    uint_fast8_t longest_dim = tree.root_node().bounding_box.longest_dimension();
    auto [ min_point_it, max_point_it ] = std::minmax_element(tree.get_points().cbegin(), tree.get_points().cend(),
                                                              [longest_dim](auto const& a, auto const& b) {
                                                                return a.get()[longest_dim] < b.get()[longest_dim];
                                                              });
    return min_point_it->get().distance(max_point_it->get());
  }

  auto
  split_node_pair(NodePairT const& node_pair) -> void {
    bool const split_left  = tree.node(node_pair.left_idx).points.size() >= brute_force_size_threshold;
    bool const split_right = tree.node(node_pair.right_idx).points.size() >= brute_force_size_threshold;

    if (split_left)
      tree.split_node(node_pair.left_idx);
    if (split_right)
      tree.split_node(node_pair.right_idx);

    TreeNodeT const& left  = tree.node(node_pair.left_idx);
    TreeNodeT const& right = tree.node(node_pair.right_idx);
    TreeNodeT const& left_left   = tree.left_child(left);
    TreeNodeT const& left_right  = tree.right_child(left);
    TreeNodeT const& right_left  = tree.left_child(right);
    TreeNodeT const& right_right = tree.right_child(right);

    if (&left == &right) {
      add_to_heap(NodePairT { left_left, left_right });
      return;
    }

    if (split_left && split_right) {
      add_to_heap(NodePairT { left_left, right_left });
      add_to_heap(NodePairT { left_left, right_right });
      add_to_heap(NodePairT { left_right, right_left });
      add_to_heap(NodePairT { left_right, right_right });
    } else if (split_left) {
      add_to_heap(NodePairT { left_left, right });
      add_to_heap(NodePairT { left_right, right });
    } else if (split_right) {
      add_to_heap(NodePairT { left, right_left });
      add_to_heap(NodePairT { left, right_right });
    }
  };

  auto
  add_to_heap(NodePairT&& node_pair) noexcept -> void {
    if (node_pair.max_diameter > max_diameter)
      heap.push(std::move(node_pair));
  };
};

}


namespace radiomics::fstdiameter {

template<ArithmeticT T, uint_fast8_t n_dims>
auto calculate_nd_diameter(std::span<Vec<T, n_dims> const> points) noexcept -> T {
  impl::Algorithm<T, n_dims> algorithm { points };

  return algorithm();
};

template<ArithmeticT T, uint_fast8_t n_dims>
auto calculate_hyperplane_diameters(std::span<Vec<T, n_dims> const> points) noexcept -> Vec<T, n_dims> {
  using PointT = Vec<T, n_dims>;
  using PointRefT = std::reference_wrapper<PointT const>;

  std::vector<PointRefT> _points {};
  _points.reserve(points.size());
  for (PointT const& point : points)
    _points.emplace_back(std::cref(point));

  Vec<T, n_dims> max_diameters {};
  for (uint_fast8_t dim = 0; dim < n_dims; ++dim) {
    std::vector<PointRefT> my_points { _points };
    std::sort(my_points.begin(), my_points.end(),
              [dim](PointT const& a, PointT const& b) { return a[dim] < b[dim]; });

    std::vector<std::span<PointRefT>> spans {};
    spans.reserve(my_points.size() / 100);
    T previous_value = my_points.front().get()[dim];
    typename std::vector<PointRefT>::iterator span_begin_it = my_points.begin();
    for (auto it = my_points.begin(); it != my_points.end(); ++it) {
      T const current_value = it->get()[dim];

      if (current_value != previous_value) {
        spans.emplace_back(span_begin_it, it);

        span_begin_it = it;
        previous_value = current_value;
      }
    }
    spans.emplace_back(span_begin_it, my_points.end());
    std::erase_if(spans, [](std::span<PointRefT> const& span) { return span.empty(); });

    auto it_bruteforce_span_end = std::partition(spans.begin(), spans.end(),
                                                 [](std::span<PointRefT> const& span) {
      return span.size() < impl::brute_force_size_threshold;
    });

    std::vector<T> diameters { spans.size(), std::allocator<T> {} };

    auto it_bruteforce_diameters_end = std::transform(spans.begin(), it_bruteforce_span_end,
                                                      diameters.begin(),
                                                      [](std::span<PointRefT> const& span) {
      T max_diameter = std::numeric_limits<T>::min();
      for (auto it_a = span.begin(); it_a != span.end(); ++it_a)
        for (auto it_b = std::next(it_a); it_b != span.end(); ++it_b)
          max_diameter = std::max(max_diameter, (it_a->get()).distance(it_b->get()));

      return max_diameter;
    });

    std::transform(it_bruteforce_span_end, spans.end(),
                   it_bruteforce_diameters_end,
                   [](std::span<PointRefT> const& span) { return impl::Algorithm<T, n_dims> { span } (); });

    max_diameters[dim] = *std::max_element(diameters.cbegin(), diameters.cend());
  }

  return max_diameters;
};

}
