#include "fstdiameter.h"

#include "../Vec.h"

auto main() -> int {
  std::vector<radiomics::Point3<double>> points {};
  for (size_t i = 100; i < 103; ++i) {
    for (size_t j = 100; j < 103; ++j) {
      for (size_t z = 100; z < 103; ++z) {
        points.emplace_back(
            radiomics::Point3<double> { static_cast<double>(i), static_cast<double>(j), static_cast<double>(z) }
        );
      }
    }
  }

  std::mt19937 random_engine { 1 };
  std::shuffle(points.begin(), points.end(), random_engine);

  radiomics::Vec3<double> spacing { 0.5, 0.5, 0.5 };

  auto const diameter = radiomics::fstdiameter::calculate_nd_diameter<double, 3>(points, spacing);
  std::cout << "diameter: " << diameter << std::endl;

  auto const hyperplane_diameters = radiomics::fstdiameter::calculate_hyperplane_diameters<double, 3>(points, spacing);
  std::cout << "diameter: x" << hyperplane_diameters[0] << ", y " << hyperplane_diameters[1] << ", z " << hyperplane_diameters[2] << std::endl;
}
