#include "cshape.h"

#include "Vec.h"
#include "fstdiameter/fstdiameter.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <execution>
#include <iostream>
#include <vector>

#include <Python.h>


namespace radiomics {

// **************************************************
// 3D Shape calculation
// **************************************************
auto calculate_meshDiameter(std::vector<Point3<double>> const& vertices) -> Vec4<double> {
  auto const diameter_3d = fstdiameter::calculate_nd_diameter<double, 3>(vertices);
  auto const diameters_2d = fstdiameter::calculate_hyperplane_diameters<double, 3>(vertices);

  return { diameters_2d[0], diameters_2d[1], diameters_2d[2], diameter_3d };
};

auto calculate_coefficients(std::span<char> mask,
                            Vec3<npy_intp> const& size,
                            Vec3<npy_intp> const& strides,
                            Vec3<double> const& spacing) noexcept -> std::optional<CoefficientResult3D> {
  using namespace detail::_3D;

  // cube identifier, 8 bits signifying which corners of the cube belong to the segmentation
  // O - X
  // |\
  // Y Z
  //           v0
  //  p0 ------------ p1
  //   |\             |\
  //   | \ v3         | \ v1
  // v8|  \      v2   |v9\
  //   |  p3 ------------ p2
  //   |   |  v4      |   |
  //  p4 --|--------- p5  |
  //    \  |v11        \  |v10
  //  v7 \ |          v5\ |
  //      \|             \|
  //      p7 ------------ p6
  //             v6
  npy_intp const number_of_cubes = (size[0] - 1) * (size[1] - 1) * (size[2] - 1);
  std::vector<uint8_t> cube_indices { static_cast<size_t>(number_of_cubes), std::allocator<uint8_t> {} };
  // Iterate over all voxels, do not include last voxels in the three dimensions, as the cube includes voxels at pos +1
  for (npy_intp iz = 0, idx = 0; iz < (size[0] - 1); ++iz)
    for (npy_intp iy = 0; iy < (size[1] - 1); ++iy)
      for (npy_intp ix = 0; ix < (size[2] - 1); ++ix, ++idx) {
        Point3<npy_intp> const idx_vec { iz, iy, ix };

        for (uint_fast8_t a_idx = 0; a_idx < 8; a_idx++) {
          npy_intp const& i = (idx_vec + grid_vertices[a_idx]).dot(strides);
          cube_indices[idx] |= (mask[i] << a_idx);  // assume elements of mask are either 0 or 1
        }
      }


  double surfaceArea = 0;  // Total surface area
  double volume = 0;  // Total volume
  auto cube_idx_it = cube_indices.begin();
  for (npy_intp iz = 0; iz < (size[0] - 1); ++iz)
    for (npy_intp iy = 0; iy < (size[1] - 1); ++iy)
      for (npy_intp ix = 0; ix < (size[2] - 1); ++ix, ++cube_idx_it) {
        auto& cube_idx = *cube_idx_it;
        Point3<double> const idx_vec { static_cast<double>(iz), static_cast<double>(iy), static_cast<double>(ix) };

        double const sign_correction = ((cube_idx & 0x80) != 0) ? -1.0 : 1.0;
        if ((cube_idx & 0x80) != 0)
          cube_idx ^= 0xff;

        // Process all triangles for this cube
        for (auto triIt = tri_table[cube_idx].begin(); !triIt->is_sentinel(); ++triIt) {

          Triangle<Point3<double>> triangle { (idx_vec + vert_list[(*triIt)[0]]) * spacing,
                                              (idx_vec + vert_list[(*triIt)[1]]) * spacing,
                                              (idx_vec + vert_list[(*triIt)[2]]) * spacing };

          // Calculate volume (division by 6 is performed at the end)
          Point3<double> ab_cross = triangle.A.cross(triangle.B);
          volume += sign_correction * ab_cross.dot(triangle.C);

          // Calculate surface area (SA = 1/2 |(a - c) x (b - c)|), where
          // the magnitude is obtained by calculating the Euclidean distance between (0, 0, 0) and the location of c
          triangle.A -= triangle.C;
          triangle.B -= triangle.C;
          ab_cross = triangle.A.cross(triangle.B);

          double const euclidian_distance = sqrt(ab_cross.sum_of_squares());
          surfaceArea += 0.5 * euclidian_distance;
        }
      }
  volume /= 6;


  // Store vertices for diameter calculation
  // create a stack to hold the found vertices. For each cube, a maximum of 3 vertices are stored (with x, y and z
  // coordinates). This prevents double storing of the vertices.
  npy_intp v_idx = 0;
  std::vector<Point3<double>> vertices { static_cast<size_t>(number_of_cubes * 3), Point3<double>::sentinel() };
  cube_idx_it = cube_indices.begin();
  for (npy_intp iz = 0; iz < (size[0] - 1); ++iz)
    for (npy_intp iy = 0; iy < (size[1] - 1); ++iy)
      for (npy_intp ix = 0; ix < (size[2] - 1); ++ix, ++cube_idx_it) {
        auto const& cube_idx = *cube_idx_it;
        Point3<double> const idx_vec { static_cast<double>(iz), static_cast<double>(iy), static_cast<double>(ix) };

        // check if there are vertices on edges 6, 7 and 11
        // Because of the symmetry around the midpoint and the flip if cube_idx > 128, the 8th point will never appear
        // as segmented at this point. Therefore, to check if there are vertices on the adjacent edges (6, 7 and 11),
        // one only needs to check if the corresponding points (7th, 5th and 4th, respectively) are segmented.
        static constexpr std::array<Point3<npy_uintp>, 2> points_edges { Point3<npy_uintp> { 6, 4, 3 }, { 6, 7, 11 } };
        for (uint8_t t = 0; t < 3; t++) {
          uint8_t const flipped_idx = (cube_idx & 0x80) != 0
                                      ? cube_idx ^ 0xff
                                      : cube_idx;

          if ((flipped_idx & (1 << points_edges[0][t])) != 0)
            vertices[v_idx++] = (idx_vec + vert_list[points_edges[1][t]]) * spacing;
        }
      }
  std::erase_if(vertices, [](auto const& p) { return p.is_sentinel(); });
  Vec4<double> diameters = calculate_meshDiameter(vertices);


  return CoefficientResult3D { surfaceArea, volume, diameters };
}





// **************************************************
// 2D Shape calculation
// **************************************************
auto calculate_coefficients2D(std::span<char> mask,
                              Vec2<npy_intp> const& size,
                              Vec2<npy_intp> const& strides,
                              Vec2<double> const& spacing) -> std::optional<CoefficientResult2D> {
  using namespace detail::_2D;

  // Get current square_idx by analyzing each point of the current square (origin is in left-upper corner)
  // square identifier, 4 bits signifying which corners of the square belong to the segmentation
  //  O - X
  //  |
  //  Y
  //         v0
  //   p0 ------- p1
  //    |         |
  // v3 |         | v1
  //    |         |
  //   p3 ------- p2
  //         v2
  npy_intp const number_of_squares = (size[0] - 1) * (size[1] - 1);
  std::vector<uint8_t> square_indices { static_cast<size_t>(number_of_squares), std::allocator<uint8_t> {} };
  for (npy_intp iy = 0, idx = 0; iy < (size[0] - 1); ++iy)
    for (npy_intp ix = 0; ix < (size[1] - 1); ++ix, ++idx)
      for (uint_fast8_t a_idx = 0; a_idx < 4; a_idx++) {
        npy_intp const i = (Point2<npy_intp>{ iy, ix } + grid_vertices[a_idx]).dot(strides);

        square_indices[idx] |= (mask[i] << a_idx);  // assume mask[i] is either 0 or 1
      }


  double perimeter = 0;
  double surface_area = 0;
  for (npy_intp iy = 0, idx = 0; iy < (size[0] - 1); ++iy)
    for (npy_intp ix = 0; ix < (size[1] - 1); ++ix, ++idx) {
      Point2<double> const idx_vec { static_cast<double>(iy), static_cast<double>(ix) };

      for (auto square_it = line_table[square_indices[idx]].begin(); !square_it->is_sentinel(); ++square_it) {

        Line<Point2<double>> square { (idx_vec + vert_list[(*square_it)[0]]) * spacing,
                                      (idx_vec + vert_list[(*square_it)[1]]) * spacing };

        // Calculate surface_area using the cross product. Because for both vectors, z = 0, only the last term need be
        // calculated. The surface_area of the triangle is only 1/2 the magnitude of this result, but the division by 2
        // is done on the final sum.
        surface_area += (square.A[0] * square.B[1]) - (square.B[0] * square.A[1]);

        // Calculate perimeter using the Euclidean distance between points a and b.
        // Add the result to the grand total, as the perimeter is the sum of all line lengths.
        perimeter += square.A.distance(square.B);
      }
    }
  // The surface_area area of the triangle is 1/2 the magnitude of the cross product.
  surface_area /= 2;


  // create a stack to hold the found vertices. For each square, a maximum of 2 vertices are stored (with x and y
  // coordinates). This prevents double storing of the vertices.
  npy_intp v_idx = 0;
  std::vector<Point2<double>> vertices {static_cast<size_t>(number_of_squares * 2), Point2<double>::sentinel() };
  // Iterate over all pixels, do not include last voxels in the three dimensions, as the cube includes voxels at pos +1
  for (npy_intp iy = 0, idx = 0; iy < (size[0] - 1); ++iy) {
    for (npy_intp ix = 0; ix < (size[1] - 1); ++ix, ++idx) {
      Point2<double> const idx_vec { static_cast<double>(iy), static_cast<double>(ix) };

      // Store vertices for diameter calculation
      // check if there are vertices on edges 3 and 2
      // Because of the symmetry around the midpoint and the flip if cube_idx > 0xF, the 4th point will never appear
      // as segmented at this point. Therefore, to check if there are vertices on the adjacent edges (3 and 2),
      // one only needs to check if the corresponding points (0 and 2, respectively) are segmented.
      static constexpr std::array<Point2<npy_uintp>, 2> points_edges { Point2<npy_uintp> { 0, 2 }, { 3, 2 } };
      for (uint8_t t = 0; t < 2; ++t) {
        uint8_t const flipped_square_idx = (square_indices[idx] & 0x8) != 0
                                           ? square_indices[idx] ^ 0xf
                                           : square_indices[idx];

        if ((flipped_square_idx & (1 << points_edges[0][t])) != 0)
          vertices[v_idx++] = (idx_vec + vert_list[points_edges[1][t]]) * spacing;
      }
    }
  }
  std::erase_if(vertices, [](auto const& p) { return p.is_sentinel(); });

  double diameter = 0;
  for (auto it_a = vertices.begin(); it_a != vertices.end(); ++it_a)
    for (auto it_b = std::next(it_a); it_b != vertices.end(); ++it_b)
      diameter = std::max(diameter, it_a->distance(*it_b));

  return CoefficientResult2D { surface_area, perimeter, diameter };
}

}
