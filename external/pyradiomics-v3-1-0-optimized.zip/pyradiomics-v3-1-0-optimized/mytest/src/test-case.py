import logging
import os

import six

import sys
from pathlib import Path

import radiomics.base

sys.path.insert(0, str(Path("./tests").resolve()))

from radiomics import getFeatureClasses
from testUtils import RadiomicsTestUtils


def generate_scenarios(tests: list[str],
                       feature_classes: dict[str, radiomics.base.RadiomicsFeaturesBase]) -> list[tuple[str, str]]:
  test_cases = []
  for test in tests:
    for feature_class_name in feature_classes:
      # Get all feature names for which there is a baseline with current test case
      # Raises an assertion error when the class is not yet present in the baseline
      # Returns None if no baseline is present for this specific test case
      # Returns a list of feature names for which baseline values are present for this test
      baselineFeatureNames = testUtils.getFeatureNames(feature_class_name, test)

      if baselineFeatureNames is None:
        continue
      assert (len(baselineFeatureNames) > 0)

      uniqueFeatures = set([f.split('_')[-1] for f in baselineFeatureNames])

      # Get a list of all features for current class
      featureNames = feature_classes[feature_class_name].getFeatureNames()
      # Get a list of all non-deprecated features
      activeFeatures = set([f for (f, deprecated) in six.iteritems(featureNames) if not deprecated])
      # Check if all active features have a baseline (exclude deprecated features from this set)
      if len(activeFeatures - uniqueFeatures) > 0:
        raise AssertionError('Missing baseline for active features %s', activeFeatures - uniqueFeatures)
      if len(uniqueFeatures - activeFeatures) > 0:
        raise AssertionError('Missing function(s) for baseline feature(s) %s', uniqueFeatures - activeFeatures)

      logging.debug('generate_scenarios: featureNames = %s', baselineFeatureNames)
      for featureName in baselineFeatureNames:
        test_cases.append((test, featureName))

  return test_cases


def test_scenario(feature_classes: dict[str, radiomics.base.RadiomicsFeaturesBase], testCase, featureName):
  featureName = featureName.split('_')

  logging.debug('test_scenario: test = %s, featureClassName = %s, featureName = %s', testCase, featureName[1],
                featureName[-1])

  testOrClassChanged = testUtils.setFeatureClassAndTestCase(featureName[1], testCase)

  testImage = testUtils.getImage(featureName[0])
  testMask = testUtils.getMask(featureName[0])

  featureClass = feature_classes[featureName[1]](testImage, testMask, **testUtils.getSettings())

  assert (featureClass is not None)

  featureClass.disableAllFeatures()
  featureClass.enableFeatureByName(featureName[-1])
  featureClass.execute()
  # get the result and test it
  val = featureClass.featureValues[featureName[-1]]
  testUtils.checkResult(featureName, val)


def teardown_module():
  print("")
  res = testUtils.getResults()
  print('Results:')
  print(res)
  resultsFile = os.path.join(testUtils.getDataDir(), 'PyradiomicsFeatures.csv')
  testUtils.writeCSV(res, resultsFile)
  diff = testUtils.getDiffs()
  print('Differences from baseline:')
  print(diff)
  diffFile = os.path.join(testUtils.getDataDir(), 'Baseline2PyradiomicsFeaturesDiff.csv')
  testUtils.writeCSV(diff, diffFile)
  logging.info(
    "Wrote calculated features to %s, and the differences between the baseline features and the calculated ones to %s.",
    resultsFile, diffFile)


if __name__ == '__main__':
  testUtils = RadiomicsTestUtils()
  tests = sorted(testUtils.getTests())
  feature_classes = getFeatureClasses()
  # print(tests)
  # print(feature_classes)

  scenarios = generate_scenarios(tests, feature_classes)
  scenario = next(s for s in scenarios if s[0] == "brain1" and s[1] == "original_shape_Maximum2DDiameterSlice")
  # scenario = next(s for s in scenarios if s[0] == "brain1" and s[1] == "original_shape_MeshVolume")
  # print(scenarios)
  # print(scenario)

  # test_scenario(feature_classes, scenario[0], scenario[1])

  print(scenario, flush=True)
  test_scenario(feature_classes, scenario[0], scenario[1])

