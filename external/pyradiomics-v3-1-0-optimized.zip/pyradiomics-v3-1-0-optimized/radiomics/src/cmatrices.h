auto calculate_glcm(int *image, char *mask, int *size, int *bb, int *strides, int *angles, int Na,
                    int Nd, double *glcm, int Ng) -> int;

auto calculate_glszm(int *image, char *mask, int *size, int *bb, int *strides, int *angles, int Na,
                     int Nd, int *tempData, int Ng, int Ns, int Nvox) -> int;

auto fill_glszm(int *tempData, double *glszm, int Ng, int maxRegion) -> int;

auto calculate_glrlm(int *image, char *mask, int *size, int *bb, int *strides, int *angles, int Na,
                     int Nd, double *glrlm, int Ng, int Nr) -> int;

auto calculate_ngtdm(int *image, char *mask, int *size, int *bb, int *strides, int *angles, int Na,
                     int Nd, double *ngtdm, int Ng) -> int;

auto calculate_gldm(int *image, char *mask, int *size, int *bb, int *strides, int *angles, int Na,
                    int Nd, double *gldm, int Ng, int alpha) -> int;

auto get_angle_count(int *size, int *distances, int Nd, int n_dist, char bidirectional, int force2Ddim) -> int;

auto build_angles(int *size, int *distances, int Nd, int n_dist, int force2Ddim, int Na, int *angles) -> int;
