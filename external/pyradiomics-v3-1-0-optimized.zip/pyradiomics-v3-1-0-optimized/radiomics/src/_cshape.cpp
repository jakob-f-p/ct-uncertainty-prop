#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION

#include <array>
#include <cstdlib>
#include <iostream>
#include <optional>

#include <numpy/arrayobject.h>
#include <Python.h>
#include <span>
#include <numeric>

#include "cshape.h"

#include "Vec.h"


namespace radiomics::py {

  namespace detail {

    template<size_t dims>
    struct CheckArraysResult {
      Vec<npy_intp, dims> Size;
      Vec<npy_intp, dims> Strides;
    };

    template<size_t dims>
    auto check_arrays(PyArrayObject *mask_arr,
                      PyArrayObject *spacing_arr) -> std::optional<CheckArraysResult<dims>> {
      if (mask_arr == nullptr || spacing_arr == nullptr) {
        Py_XDECREF(mask_arr);
        Py_XDECREF(spacing_arr);
        PyErr_SetString(PyExc_RuntimeError, "Error parsing array arguments.");
        return std::nullopt;
      }

      if (PyArray_NDIM(mask_arr) != dims || PyArray_NDIM(spacing_arr) != 1) {
        Py_XDECREF(mask_arr);
        Py_XDECREF(spacing_arr);
        PyErr_Format(PyExc_ValueError, "Expected a %iD array for mask, 1D for spacing.", dims);
        return std::nullopt;
      }

      if (!PyArray_IS_C_CONTIGUOUS(mask_arr) || !PyArray_IS_C_CONTIGUOUS(spacing_arr)) {
        Py_XDECREF(mask_arr);
        Py_XDECREF(spacing_arr);
        PyErr_SetString(PyExc_ValueError, "Expecting input arrays to be C-contiguous.");
        return std::nullopt;
      }

      if (PyArray_DIM(spacing_arr, 0) != PyArray_NDIM(mask_arr)) {
        Py_XDECREF(mask_arr);
        Py_XDECREF(spacing_arr);
        PyErr_SetString(PyExc_ValueError, "Expecting spacing array to have shape (3,).");
        return std::nullopt;
      }

      // Get sizes and strides of the arrays
      npy_intp* arrayDims = PyArray_DIMS(mask_arr);
      Vec<npy_intp, dims> size;
      std::copy(arrayDims, std::next(arrayDims, dims), size.begin());

      npy_intp const itemSize = PyArray_ITEMSIZE(mask_arr);
      npy_intp const* arrayStrides = PyArray_STRIDES(mask_arr);
      Vec<npy_intp, dims> byteStrides;
      std::copy(arrayStrides, std::next(arrayStrides, dims), byteStrides.begin());
      Vec<npy_intp, dims> const strides = byteStrides / itemSize;

      return CheckArraysResult<dims> { size, strides };
    }

  }

  auto cshape_calculate_coefficients(PyObject *self, PyObject *args) -> PyObject* {
    // Parse the input tuple
    PyObject* mask_obj = nullptr;
    PyObject* spacing_obj = nullptr;
    if (PyArg_ParseTuple(args, "OO", &mask_obj, &spacing_obj) == 0)
      return nullptr;

    // Interpret the input as numpy arrays
    auto *mask_arr = (PyArrayObject*) PyArray_FROM_OTF(mask_obj, NPY_BYTE, NPY_ARRAY_FORCECAST | NPY_ARRAY_IN_ARRAY);
    auto *spacing_arr = (PyArrayObject*) PyArray_FROM_OTF(spacing_obj, NPY_DOUBLE, NPY_ARRAY_FORCECAST | NPY_ARRAY_IN_ARRAY);

    auto const check_res = detail::check_arrays<3>(mask_arr, spacing_arr);
    if (!check_res)
      return nullptr;

    auto [ size, strides] = *check_res;

    // Get arrays in Ctype
    auto* mask = (char*) PyArray_DATA(mask_arr);
    auto* spacing = (double*) PyArray_DATA(spacing_arr);

    size_t const n_voxels = std::reduce(size.begin(), size.end(), 1ULL, std::multiplies{});
    std::span<char> const maskSpan { mask, n_voxels };

    Vec3<double> spacingVec;
    std::copy(spacing, std::next(spacing, 3), spacingVec.begin());

    auto const coeff_res = calculate_coefficients(maskSpan, size, strides, spacingVec);
    if (!coeff_res) {
      Py_XDECREF(mask_arr);
      Py_XDECREF(spacing_arr);
      PyErr_SetString(PyExc_RuntimeError, "Calculation of Shape coefficients failed.");
      return nullptr;
    }

    // Clean up
    Py_XDECREF(mask_arr);
    Py_XDECREF(spacing_arr);

    auto const& diameters = coeff_res->Diameters;
    PyObject* diameter_obj = Py_BuildValue("ffff", diameters[0], diameters[1], diameters[2], diameters[3]);

    return Py_BuildValue("ffN", coeff_res->SurfaceArea, coeff_res->Volume, diameter_obj);
  };

  auto cshape_calculate_coefficients2D(PyObject *self, PyObject *args) -> PyObject* {
    // Parse the input tuple
    PyObject* mask_obj = nullptr;
    PyObject* spacing_obj = nullptr;
    if (PyArg_ParseTuple(args, "OO", &mask_obj, &spacing_obj) == 0)
      return nullptr;

    // Interpret the input as numpy arrays
    auto* mask_arr = (PyArrayObject*) PyArray_FROM_OTF(mask_obj, NPY_BYTE, NPY_ARRAY_FORCECAST | NPY_ARRAY_IN_ARRAY);
    auto* spacing_arr = (PyArrayObject*) PyArray_FROM_OTF(spacing_obj, NPY_DOUBLE, NPY_ARRAY_FORCECAST | NPY_ARRAY_IN_ARRAY);

    auto const check_res = detail::check_arrays<2>(mask_arr, spacing_arr);
    if (!check_res)
      return nullptr;

    auto [ size, strides] = *check_res;

    // Get arrays in Ctype
    auto* mask = (char*) PyArray_DATA(mask_arr);
    auto* spacing = (double*) PyArray_DATA(spacing_arr);

    size_t const n_pixels = std::reduce(size.begin(), size.end(), 1ULL, std::multiplies{});
    std::span<char> const maskSpan { mask, n_pixels };

    Vec2<double> spacingVec;
    std::copy(spacing, std::next(spacing, 2), spacingVec.begin());
    auto const coeff_res = calculate_coefficients2D(maskSpan, size, strides, spacingVec);
    if (!coeff_res) {
      // An error has occurred
      Py_XDECREF(mask_arr);
      Py_XDECREF(spacing_arr);
      PyErr_SetString(PyExc_RuntimeError, "Calculation of Shape coefficients failed.");
      return nullptr;
    }

    // Clean up
    Py_XDECREF(mask_arr);
    Py_XDECREF(spacing_arr);

    return Py_BuildValue("fff", coeff_res->Perimeter, coeff_res->SurfaceArea, coeff_res->Diameter);
  };

  constexpr std::string_view module_docstring {
      "This module links to C-compiled code for efficient calculation of the surface area "
      "in the pyRadiomics package. It provides fast calculation using a marching cubes "
      "algortihm, accessed via ""calculate_surfacearea"". Arguments for this function"
      "are positional and consist of two numpy arrays, mask and pixelspacing, which must "
      "be supplied in this order. Pixelspacing is a 3 element Vec containing the pixel"
      "spacing in z, y and x dimension, respectively. All non-zero elements in mask are "
      "considered to be a part of the segmentation and are included in the algorithm." };

  constexpr std::string_view coefficients_docstring {
      "Arguments: Mask, PixelSpacing. Uses a marching cubes algorithm to calculate an "
      "approximation to the total surface area, volume and maximum diameters. "
      "The isovalue is considered to be situated midway between a voxel that is part "
      "of the segmentation and a voxel that is not." };

  constexpr std::string_view coefficients2D_docstring {
      "Arguments: Mask, PixelSpacing. Uses an adapted 2D marching cubes algorithm "
      "to calculate an approximation to the total perimeter, surface and maximum "
      "diameter. The isovalue is considered to be situated midway between a pixel "
      "that is part of the segmentation and a pixel that is not." };

  std::array<PyMethodDef, 3> module_methods { PyMethodDef
      //{"calculate_", cmatrices_, METH_VARARGS, _docstring},
      { "calculate_coefficients", cshape_calculate_coefficients, METH_VARARGS, coefficients_docstring.data() },
      { "calculate_coefficients2D", cshape_calculate_coefficients2D, METH_VARARGS, coefficients2D_docstring.data() },
      { nullptr, nullptr, 0, nullptr }
  };

#if PY_MAJOR_VERSION >= 3
  static struct PyModuleDef moduledef = {
      PyModuleDef_HEAD_INIT,
      "_cshape",           /* m_name */
      module_docstring.data(),    /* m_doc */
      -1,                  /* m_size */
      module_methods.data(),      /* m_methods */
      nullptr,                /* m_reload */
      nullptr,                /* m_traverse */
      nullptr,                /* m_clear */
      nullptr,                /* m_free */
  };
#endif

  auto
  moduleinit() -> PyObject * {
    PyObject *m;

#if PY_MAJOR_VERSION >= 3
    m = PyModule_Create(&moduledef);
#else
    m = Py_InitModule3("_cshape", module_methods, module_docstring);
#endif

    return m;
  }

}


#if PY_MAJOR_VERSION < 3
  PyMODINIT_FUNC
  init_cshape(void) {
    // Initialize numpy functionality
    import_array();

    py::moduleinit();
  }
#else
  PyMODINIT_FUNC
  PyInit__cshape() {
    // Initialize numpy functionality
    import_array();

    return radiomics::py::moduleinit();
  }
#endif
